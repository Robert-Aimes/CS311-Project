package com.company;

public class Question {
    String prompt;


    public Question(String prompt){
        this.prompt = prompt;

    }

    public String getPrompt(){
        return prompt;
    }


}
